ASLAN'IN MACERASI — Ücretsiz oynanabilir ilk prototip

1) Bilgisayarda index.html dosyasını çift tıklayarak açabilirsiniz.
2) iPhone'da en iyi deneyim için index.html dosyasını ücretsiz statik site barındırmasına (ör. GitHub Pages) yayınlayıp Safari'den açın.
3) Safari > Paylaş > Ana Ekrana Ekle ile uygulama simgesi gibi başlatabilirsiniz.

Bu prototipte 3 bölüm var:
- Renkleri bul: 4 soru
- Şekilleri bul: 4 soru
- Yıldızları say: 5 yıldız

Tek HTML dosyasıdır. İnternet bağlantısı gerektiren kaynak, reklam, satın alma veya veri toplama yoktur. Oyun açıldıktan sonra çevrimdışı çalışır (site üzerinde çevrimdışı açılma için ayrıca PWA yapılandırması gerekir).

Bu, henüz App Store'a yüklenmiş yerel iOS uygulaması değildir.
